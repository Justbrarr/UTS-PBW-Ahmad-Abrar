document.addEventListener("DOMContentLoaded", function() {

    const backToHome = document.getElementById("backToHome");
    if (backToHome) {
        backToHome.addEventListener("click", function() {
            window.location.href = "#beranda";
        });
    }

    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function(event) {
            event.preventDefault();
            alert("Pesan berhasil dikirim!");
        });
    }
});
